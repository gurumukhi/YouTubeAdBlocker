# adblocker-for-youtube
A cross browser add-on to remove all annoying Ads and Banners from YouTube.